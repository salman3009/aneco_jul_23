import './List.css';

const List=(props)=>{
    return(<div>
         <h1>The given name is {props.name}</h1>
    </div>)
}
export default List;