import Register from "./Register/Register";
import Login from "./Login/Login";
import Table from "./Table/Table";
import './assets/font-awesome/css/font-awesome.min.css'
function App() {
  return (
    <div className="App">
       {/* <Register/> */}
       {/* <Login/> */}
       <Table/>
    </div>
  );
}

export default App;
