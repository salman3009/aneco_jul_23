
const Expression =()=>{
    let input= "muthu";
    
       return (<div>
         <div>{"welcome to javacript"}</div>
         <div>{2+2}</div>
         <div>{false}</div>
         <div>{input}</div>
       </div>)
}
export default Expression;