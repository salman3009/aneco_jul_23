
function App(){
 
    return (<div>
        <h1>First app</h1>
    </div>)
}
export default App;