import './Mobile.css';
const Mobile=()=>{
      return (<div className="box">
        <h1>Mobile Name:Samsung</h1>
        <h2>Amount:2000</h2>
        <h3>Discount:0</h3>
      </div>)
}
export default Mobile;