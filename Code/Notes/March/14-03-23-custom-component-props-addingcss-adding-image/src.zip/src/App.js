import Mobile from "./Mobile/Mobile";
function App(){
 
    return (<div>
        <h1>
            <Mobile/>
            <Mobile/>
            <Mobile/> 
        </h1>
    </div>)
}
export default App;